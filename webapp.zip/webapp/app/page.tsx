"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, ReferenceLine } from "recharts";
import { Activity, TrendingUp, Database, Clock, RefreshCw, Pause, Play, Radio, Timer, Warehouse, Check } from "lucide-react";

interface TimeSeriesData {
  TIMESTAMP: string;
  TAGNAME: string;
  VALUE: number;
}

interface TagData {
  TAGNAME: string;
  COUNT: number;
}

interface StatsData {
  TAGNAME: string;
  MIN_VALUE: number;
  MAX_VALUE: number;
  AVG_VALUE: number;
  STDDEV_VALUE: number;
  COUNT: number;
}

interface LatestData {
  TAGNAME: string;
  TIMESTAMP: string;
  VALUE: number;
  INGEST_TIMESTAMP: string;
}

interface Avg5MinData {
  TAGNAME: string;
  AVG_VALUE: number;
  COUNT: number;
  latencyMs: number;
}

function formatTimeAgo(timestamp: string, serverTime: string): string {
  const readingStr = timestamp.includes('Z') || timestamp.includes('+') ? timestamp : timestamp + 'Z';
  const serverStr = serverTime.includes('Z') || serverTime.includes('+') ? serverTime : serverTime + 'Z';
  const reading = new Date(readingStr);
  const now = new Date(serverStr);
  const diffMs = now.getTime() - reading.getTime();
  const seconds = Math.floor(diffMs / 1000);
  return `${seconds.toLocaleString()}s ago`;
}

const ALL_SENSORS = [
  "SENSOR/TAG101",
  "SENSOR/TAG201", 
  "SENSOR/TAG301",
  "SENSOR/TAG401",
  "SENSOR/TAG501",
  "SENSOR/TAG601",
];

export default function Home() {
  const [tags, setTags] = useState<TagData[]>([]);
  const [selectedTag, setSelectedTag] = useState<string>("SENSOR/TAG101");
  const [enabledSensors, setEnabledSensors] = useState<string[]>(ALL_SENSORS.filter(s => s !== "SENSOR/TAG601"));
  const [timeSeriesData, setTimeSeriesData] = useState<TimeSeriesData[]>([]);
  const [stats, setStats] = useState<StatsData[]>([]);
  const [latestData, setLatestData] = useState<LatestData[]>([]);
  const [serverTime, setServerTime] = useState<string>("");
  const [avg5MinData, setAvg5MinData] = useState<Avg5MinData[]>([]);
  const [loading, setLoading] = useState(true);
  const [chartLoading, setChartLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState(5);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [selectedWarehouse, setSelectedWarehouse] = useState<string>("COMPUTE_WH");
  const [avgQueryRuntime, setAvgQueryRuntime] = useState<number>(0);
  const [minQueryRuntime, setMinQueryRuntime] = useState<number>(0);
  const [maxQueryRuntime, setMaxQueryRuntime] = useState<number>(0);
  const queryTimesRef = useRef<number[]>([]);

  const [avgLatestRuntime, setAvgLatestRuntime] = useState<number>(0);
  const [minLatestRuntime, setMinLatestRuntime] = useState<number>(0);
  const [maxLatestRuntime, setMaxLatestRuntime] = useState<number>(0);
  const latestTimesRef = useRef<number[]>([]);

  const trackQueryTime = (ms: number) => {
    queryTimesRef.current = [...queryTimesRef.current.slice(-9), ms];
    const times = queryTimesRef.current;
    setAvgQueryRuntime(times.reduce((a, b) => a + b, 0) / times.length);
    setMinQueryRuntime(Math.min(...times));
    setMaxQueryRuntime(Math.max(...times));
  };

  const trackLatestTime = (ms: number) => {
    latestTimesRef.current = [...latestTimesRef.current.slice(-9), ms];
    const times = latestTimesRef.current;
    setAvgLatestRuntime(times.reduce((a, b) => a + b, 0) / times.length);
    setMinLatestRuntime(Math.min(...times));
    setMaxLatestRuntime(Math.max(...times));
  };

  const toggleSensor = (sensor: string) => {
    setEnabledSensors(prev => 
      prev.includes(sensor) 
        ? prev.filter(s => s !== sensor)
        : [...prev, sensor].sort()
    );
  };

  const fetchData = useCallback(async () => {
    if (enabledSensors.length === 0) return;
    
    const tagsData = await fetch(`/api/tags?warehouse=${selectedWarehouse}`).then(res => res.json());
    
    const statsResults = await Promise.all(
      enabledSensors.map(tag =>
        fetch(`/api/stats?warehouse=${selectedWarehouse}&tag=${encodeURIComponent(tag)}`)
          .then(res => res.json())
          .then(data => data[0])
      )
    );
    
    const latestStart = performance.now();
    const latestResults = await Promise.all(
      enabledSensors.map(tag =>
        fetch(`/api/latest?warehouse=${selectedWarehouse}&tag=${encodeURIComponent(tag)}`)
          .then(res => res.json())
          .then(data => ({ item: data.data?.[0], serverTime: data.serverTime }))
      )
    );
    trackLatestTime(performance.now() - latestStart);
    
    const start = performance.now();
    const avg5MinResults = await Promise.all(
      enabledSensors.map(tag =>
        fetch(`/api/avg5min?warehouse=${selectedWarehouse}&tag=${encodeURIComponent(tag)}`)
          .then(res => res.json())
      )
    );
    trackQueryTime(performance.now() - start);
    
    setTags(tagsData);
    setStats(statsResults.filter(Boolean));
    setLatestData(latestResults.map(r => r.item).filter(Boolean));
    setAvg5MinData(avg5MinResults.filter(Boolean));
    setServerTime(latestResults[0]?.serverTime || new Date().toISOString());
    setLastUpdated(new Date());
  }, [selectedWarehouse, enabledSensors]);

  const fetchTimeSeries = useCallback(async (tag: string) => {
    const data = await fetch(`/api/timeseries?tag=${encodeURIComponent(tag)}&limit=500&warehouse=${selectedWarehouse}`).then(res => res.json());
    setTimeSeriesData(data);
    setLastUpdated(new Date());
  }, [selectedWarehouse]);

  useEffect(() => {
    fetchData().then(() => setLoading(false));
  }, [fetchData]);

  useEffect(() => {
    if (selectedTag) {
      setChartLoading(true);
      fetchTimeSeries(selectedTag).then(() => setChartLoading(false));
    }
  }, [selectedTag, fetchTimeSeries]);

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      fetchData();
      if (selectedTag) {
        fetchTimeSeries(selectedTag);
      }
    }, refreshInterval * 1000);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, selectedTag, fetchData, fetchTimeSeries]);

  const chartData = timeSeriesData.map(d => ({
    timestamp: new Date(d.TIMESTAMP).toLocaleTimeString(),
    value: d.VALUE
  }));

  const chartMin = timeSeriesData.length > 0 ? Math.min(...timeSeriesData.map(d => d.VALUE)) : null;
  const chartMax = timeSeriesData.length > 0 ? Math.max(...timeSeriesData.map(d => d.VALUE)) : null;

  const selectedStats = stats.find(s => s.TAGNAME === selectedTag);
  const totalRows = stats.reduce((sum, s) => sum + s.COUNT, 0);

  const chartConfig = {
    value: {
      label: "Value",
      color: "#10b981",
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-12 w-64 bg-zinc-800" />
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-32 bg-zinc-800" />
            ))}
          </div>
          <Skeleton className="h-96 bg-zinc-800" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">IOT Time Series Dashboard</h1>
            <p className="text-zinc-400 mt-1">Real-time sensor data from Snowflake</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-zinc-900 rounded-lg px-3 py-2 border border-zinc-800">
              <Warehouse className="w-4 h-4 text-zinc-500" />
              <Select value={selectedWarehouse} onValueChange={setSelectedWarehouse}>
                <SelectTrigger className="w-40 h-8 bg-zinc-800 border-zinc-700 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  <SelectItem value="COMPUTE_WH" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">COMPUTE_WH</SelectItem>
                  <SelectItem value="INTERACTIVE_WH" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">INTERACTIVE_WH</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 bg-zinc-900 rounded-lg px-3 py-2 border border-zinc-800">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={autoRefresh ? "text-emerald-400 hover:text-emerald-300" : "text-zinc-400 hover:text-zinc-300"}
              >
                {autoRefresh ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </Button>
              <Input
                type="number"
                min={1}
                max={60}
                value={refreshInterval}
                onChange={(e) => setRefreshInterval(Math.max(1, Math.min(60, parseInt(e.target.value) || 5)))}
                className="w-16 h-8 bg-zinc-800 border-zinc-700 text-center text-sm"
              />
              <span className="text-zinc-500 text-sm">sec</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { fetchData(); fetchTimeSeries(selectedTag); }}
                className="text-zinc-400 hover:text-zinc-300"
              >
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
            <Badge variant="outline" className={autoRefresh ? "text-emerald-400 border-emerald-400/50" : "text-zinc-500 border-zinc-700"}>
              <Activity className="w-3 h-3 mr-1" />
              {autoRefresh ? "Auto" : "Paused"}
            </Badge>
          </div>
        </div>

        {lastUpdated && (
          <p className="text-zinc-600 text-xs">Last updated: {lastUpdated.toLocaleTimeString()}</p>
        )}

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-zinc-100 flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400" />
              Sensors
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Select which sensors to query (queries run concurrently for each enabled sensor)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {ALL_SENSORS.map((sensor) => (
                <Button
                  key={sensor}
                  variant="outline"
                  size="sm"
                  onClick={() => toggleSensor(sensor)}
                  className={enabledSensors.includes(sensor) 
                    ? "bg-emerald-950/50 border-emerald-700 text-emerald-400 hover:bg-emerald-950/70" 
                    : "bg-zinc-800/50 border-zinc-700 text-zinc-500 hover:bg-zinc-800"
                  }
                >
                  {enabledSensors.includes(sensor) && <Check className="w-3 h-3 mr-1" />}
                  {sensor.replace("SENSOR/", "")}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEnabledSensors(enabledSensors.length === ALL_SENSORS.length ? [] : ALL_SENSORS)}
                className="bg-zinc-800/50 border-zinc-700 text-zinc-400 hover:bg-zinc-800"
              >
                {enabledSensors.length === ALL_SENSORS.length ? "None" : "All"}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-4 gap-4">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-zinc-500">Total Records</CardDescription>
              <CardTitle className="text-2xl text-zinc-100">{totalRows.toLocaleString()}</CardTitle>
            </CardHeader>
            <CardContent>
              <Database className="w-4 h-4 text-zinc-500" />
            </CardContent>
          </Card>
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-zinc-500">Active Sensors</CardDescription>
              <CardTitle className="text-2xl text-zinc-100">{tags.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <Activity className="w-4 h-4 text-zinc-500" />
            </CardContent>
          </Card>
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-zinc-500">Latest Latency (10)</CardDescription>
              <CardTitle className="text-2xl text-zinc-100">
                {avgLatestRuntime > 0 ? `${Math.round(avgLatestRuntime)}ms` : "-"}
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center gap-3 text-xs">
              <Timer className="w-4 h-4 text-zinc-500" />
              <span className="text-zinc-500">Min: <span className="text-zinc-100">{minLatestRuntime > 0 ? `${Math.round(minLatestRuntime)}ms` : "-"}</span></span>
              <span className="text-zinc-500">Max: <span className="text-zinc-100">{maxLatestRuntime > 0 ? `${Math.round(maxLatestRuntime)}ms` : "-"}</span></span>
            </CardContent>
          </Card>
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-2">
              <CardDescription className="text-zinc-500">5min Avg Latency (10)</CardDescription>
              <CardTitle className="text-2xl text-zinc-100">
                {avgQueryRuntime > 0 ? `${Math.round(avgQueryRuntime)}ms` : "-"}
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center gap-3 text-xs">
              <Timer className="w-4 h-4 text-zinc-500" />
              <span className="text-zinc-500">Min: <span className="text-zinc-100">{minQueryRuntime > 0 ? `${Math.round(minQueryRuntime)}ms` : "-"}</span></span>
              <span className="text-zinc-500">Max: <span className="text-zinc-100">{maxQueryRuntime > 0 ? `${Math.round(maxQueryRuntime)}ms` : "-"}</span></span>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-zinc-100 flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400" />
              Latest Readings
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Most recent value for each enabled sensor with time since reading
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {latestData.map((item) => (
                <div 
                  key={item.TAGNAME} 
                  className={`p-3 rounded-lg border ${
                    item.TAGNAME === selectedTag 
                      ? "bg-emerald-950/30 border-emerald-800" 
                      : "bg-zinc-800/50 border-zinc-700"
                  }`}
                >
                  <div className="text-xs text-zinc-500 truncate">{item.TAGNAME}</div>
                  <div className="text-xl font-mono font-semibold text-zinc-100 mt-1">
                    {item.VALUE.toFixed(2)}
                  </div>
                  <div className="text-xs text-zinc-400 mt-1">
                    {new Date(item.TIMESTAMP).toLocaleString('en-GB', {
                      day: '2-digit', month: '2-digit', year: 'numeric',
                      hour: '2-digit', minute: '2-digit', second: '2-digit'
                    })}
                  </div>
                  <div className={`text-xs mt-1 ${
                    serverTime && (new Date(serverTime).getTime() - new Date(item.TIMESTAMP).getTime()) < 60000
                      ? "text-emerald-400"
                      : "text-amber-400"
                  }`}>
                    {serverTime ? formatTimeAgo(item.TIMESTAMP, serverTime) : "-"}
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-zinc-100 mt-3">
              Time comparison = Server time when API response returned - Reading TIMESTAMP (both treated as UTC)
            </p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-zinc-100 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              5-Minute Averages
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Average value over the last 5 minutes for each enabled sensor
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {avg5MinData.map((item) => (
                <div 
                  key={item.TAGNAME} 
                  className={`p-3 rounded-lg border ${
                    item.TAGNAME === selectedTag 
                      ? "bg-emerald-950/30 border-emerald-800" 
                      : "bg-zinc-800/50 border-zinc-700"
                  }`}
                >
                  <div className="text-xs text-zinc-500 truncate">{item.TAGNAME}</div>
                  <div className="text-xl font-mono font-semibold text-zinc-100 mt-1">
                    {item.AVG_VALUE.toFixed(2)}
                  </div>
                  <div className="text-xs text-amber-400 mt-1">
                    {item.COUNT} readings · {item.latencyMs}ms
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="chart" className="space-y-4">
          <div className="flex items-center justify-between">
            <TabsList className="bg-zinc-900">
              <TabsTrigger value="chart" className="text-zinc-400 data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100">Chart</TabsTrigger>
              <TabsTrigger value="table" className="text-zinc-400 data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100">Data</TabsTrigger>
              <TabsTrigger value="stats" className="text-zinc-400 data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100">Statistics</TabsTrigger>
            </TabsList>
            <Select value={selectedTag} onValueChange={setSelectedTag}>
              <SelectTrigger className="w-48 bg-zinc-900 border-zinc-800">
                <SelectValue placeholder="Select sensor" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-zinc-800">
                {tags.map(tag => (
                  <SelectItem key={tag.TAGNAME} value={tag.TAGNAME} className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
                    {tag.TAGNAME}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <TabsContent value="chart">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-zinc-100">{selectedTag}</CardTitle>
                <CardDescription className="text-zinc-500">
                  Time series visualization (last 500 readings)
                </CardDescription>
              </CardHeader>
              <CardContent>
                {chartLoading ? (
                  <Skeleton className="h-80 bg-zinc-800" />
                ) : (
                  <ChartContainer config={chartConfig} className="h-80 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 10, right: 80, bottom: 20, left: 10 }}>
                        <XAxis
                          dataKey="timestamp"
                          stroke="#f4f4f5"
                          tick={{ fill: '#f4f4f5', fontSize: 14 }}
                          fontSize={14}
                        />
                        <YAxis
                          stroke="#f4f4f5"
                          tick={{ fill: '#f4f4f5', fontSize: 14 }}
                          fontSize={14}
                          tickLine={false}
                          axisLine={false}
                          tickFormatter={(value) => `${Math.round(value)}`}
                          domain={chartMin !== null && chartMax !== null ? [chartMin * 0.99, chartMax * 1.01] : ['auto', 'auto']}
                        />
                        <YAxis
                          yAxisId="right"
                          orientation="right"
                          fontSize={14}
                          tickLine={false}
                          axisLine={false}
                          domain={chartMin !== null && chartMax !== null ? [chartMin * 0.99, chartMax * 1.01] : ['auto', 'auto']}
                          ticks={chartMin !== null && chartMax !== null ? [chartMin, chartMax] : []}
                          tick={({ x, y, payload }) => {
                            const isMax = payload.value === chartMax;
                            return (
                              <text x={x} y={y} fill={isMax ? '#22c55e' : '#ef4444'} fontSize={14} textAnchor="start" dy={4}>
                                {isMax ? `Max: ${payload.value.toFixed(2)}` : `Min: ${payload.value.toFixed(2)}`}
                              </text>
                            );
                          }}
                        />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        {chartMin !== null && chartMax !== null && (
                          <>
                            <ReferenceLine 
                              y={chartMax} 
                              stroke="#22c55e" 
                              strokeDasharray="5 5"
                              strokeWidth={2}
                            />
                            <ReferenceLine 
                              y={chartMin} 
                              stroke="#ef4444" 
                              strokeDasharray="5 5"
                              strokeWidth={2}
                            />
                          </>
                        )}
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="#10b981"
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="table">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-zinc-100">Raw Data</CardTitle>
                <CardDescription className="text-zinc-500">
                  Recent readings for {selectedTag}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-zinc-800">
                      <TableHead className="text-zinc-400">Timestamp</TableHead>
                      <TableHead className="text-zinc-400">Tag</TableHead>
                      <TableHead className="text-zinc-400 text-right">Value</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {timeSeriesData.slice(0, 20).map((row, i) => (
                      <TableRow key={i} className="border-zinc-800">
                        <TableCell className="text-zinc-300">
                          {new Date(row.TIMESTAMP).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-zinc-400 border-zinc-700">
                            {row.TAGNAME}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono text-zinc-300">
                          {row.VALUE.toFixed(3)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="stats">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-zinc-100">Sensor Statistics</CardTitle>
                <CardDescription className="text-zinc-500">
                  Aggregate statistics for all sensors
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-zinc-800">
                      <TableHead className="text-zinc-400">Sensor</TableHead>
                      <TableHead className="text-zinc-400 text-right">Min</TableHead>
                      <TableHead className="text-zinc-400 text-right">Max</TableHead>
                      <TableHead className="text-zinc-400 text-right">Avg</TableHead>
                      <TableHead className="text-zinc-400 text-right">Std Dev</TableHead>
                      <TableHead className="text-zinc-400 text-right">Count</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {stats.map((row) => (
                      <TableRow key={row.TAGNAME} className="border-zinc-800">
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={row.TAGNAME === selectedTag ? "text-emerald-400 border-emerald-400/50" : "text-zinc-400 border-zinc-700"}
                          >
                            {row.TAGNAME}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono text-zinc-300">
                          {row.MIN_VALUE.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right font-mono text-zinc-300">
                          {row.MAX_VALUE.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right font-mono text-zinc-300">
                          {row.AVG_VALUE.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right font-mono text-zinc-300">
                          {row.STDDEV_VALUE.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right font-mono text-zinc-300">
                          {row.COUNT.toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-zinc-100 flex items-center gap-2">
              Architecture
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Interactive streaming pipeline overview
            </CardDescription>
          </CardHeader>
          <CardContent>
            <img 
              src="/interactive-streaming.png" 
              alt="Interactive Streaming Architecture" 
              className="w-full rounded-lg"
            />
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-4 items-stretch">
          <Card className="bg-zinc-900 border-zinc-800 flex flex-col">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-zinc-100 flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                Streaming Payload
              </CardTitle>
              <CardDescription className="text-zinc-500">
                Example JSON payload sent via Snowpipe Streaming SDK
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <pre className="text-sm font-mono text-zinc-300 bg-zinc-950 rounded-lg p-4 overflow-x-auto">{`{
  "RECORD_CONTENT": {
    "tagname": "SENSOR/TAG101",
    "timestamp": "1740000000",
    "value": "23.45",
    "units": "celsius",
    "datatype": "float"
  },
  "RECORD_METADATA": {
    "topic": "time-series",
    "partition": "1",
    "offset": "1",
    "LogAppendTime": "1740000000000",
    "headers": {
      "speed": "SLOW",
      "source": "STREAM_DATA.csv",
      "namespace": "IOT"
    }
  }
}`}</pre>
            </CardContent>
          </Card>
          <Card className="bg-zinc-900 border-zinc-800 flex flex-col">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-zinc-100 flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                Transformation SQL
              </CardTitle>
              <CardDescription className="text-zinc-500">
                Interactive table definition with streaming data source
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <pre className="text-sm font-mono text-zinc-300 bg-zinc-950 rounded-lg p-4 overflow-x-auto">{`CREATE OR REPLACE INTERACTIVE TABLE
  HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2 (
  timestamp TIMESTAMP_NTZ,
  tagname VARCHAR,
  value FLOAT,
  broker_timestamp TIMESTAMP_NTZ,
  ingest_timestamp TIMESTAMP_NTZ
) CLUSTER BY (
  TRUNC(TO_DATE(timestamp), 'week'), tagname
)
AS (
  SELECT
    $1:RECORD_CONTENT.timestamp AS timestamp,
    $1:RECORD_CONTENT.tagname AS tagname,
    $1:RECORD_CONTENT.value AS value,
    $1:RECORD_METADATA.LogAppendTime
      AS broker_timestamp,
    SYSDATE() AS ingest_timestamp
  FROM TABLE(
    DATA_SOURCE(TYPE => 'STREAMING')
  )
)`}</pre>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

import { NextResponse } from "next/server";
import { query } from "@/lib/snowflake";

interface Avg5MinRow {
  TAGNAME: string;
  AVG_VALUE: number;
  COUNT: number;
}

interface Avg5MinResponse {
  TAGNAME: string;
  AVG_VALUE: number;
  COUNT: number;
  latencyMs: number;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const warehouse = searchParams.get("warehouse") || undefined;
  const tag = searchParams.get("tag");

  if (!tag) {
    return NextResponse.json({ error: "tag parameter required" }, { status: 400 });
  }

  try {
    const start = performance.now();
    const results = await query<Avg5MinRow>(`
      SELECT 
        TAGNAME,
        AVG(VALUE) as AVG_VALUE,
        COUNT(*) as COUNT
      FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2
      WHERE TAGNAME = '${tag}'
        AND TIMESTAMP >= DATEADD(minute, -5, (SELECT MAX(TIMESTAMP) FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2 WHERE TAGNAME = '${tag}'))
      GROUP BY TAGNAME
    `, warehouse);
    const latencyMs = Math.round(performance.now() - start);
    
    if (!results[0]) {
      return NextResponse.json(null);
    }
    
    const response: Avg5MinResponse = {
      ...results[0],
      latencyMs
    };
    return NextResponse.json(response);
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Failed to fetch 5min avg" }, { status: 500 });
  }
}

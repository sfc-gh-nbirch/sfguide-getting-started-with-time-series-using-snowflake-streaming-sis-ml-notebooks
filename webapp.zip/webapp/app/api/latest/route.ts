import { NextResponse } from "next/server";
import { query } from "@/lib/snowflake";

interface LatestRow {
  TAGNAME: string;
  TIMESTAMP: string;
  VALUE: number;
  INGEST_TIMESTAMP: string;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const warehouse = searchParams.get("warehouse") || undefined;
  const tag = searchParams.get("tag");

  try {
    const sql = tag
      ? `SELECT TAGNAME, TIMESTAMP, VALUE, INGEST_TIMESTAMP
         FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2
         WHERE TAGNAME = '${tag}'
         ORDER BY TIMESTAMP DESC
         LIMIT 1`
      : `SELECT TAGNAME, TIMESTAMP, VALUE, INGEST_TIMESTAMP
         FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2
         QUALIFY ROW_NUMBER() OVER (PARTITION BY TAGNAME ORDER BY TIMESTAMP DESC) = 1
         ORDER BY TAGNAME`;
    
    const results = await query<LatestRow>(sql, warehouse);
    return NextResponse.json({ 
      data: results,
      serverTime: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Failed to fetch latest data" }, { status: 500 });
  }
}

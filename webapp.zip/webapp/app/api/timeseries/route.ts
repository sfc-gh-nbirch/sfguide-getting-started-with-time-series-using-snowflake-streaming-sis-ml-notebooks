import { NextResponse } from "next/server";
import { query } from "@/lib/snowflake";

interface TimeSeriesRow {
  TIMESTAMP: string;
  TAGNAME: string;
  VALUE: number;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const tag = searchParams.get("tag") || "SENSOR/TAG101";
  const limit = searchParams.get("limit") || "10";
  const warehouse = searchParams.get("warehouse") || undefined;

  try {
    const results = await query<TimeSeriesRow>(`
      SELECT TIMESTAMP, TAGNAME, VALUE
      FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2
      WHERE TAGNAME = '${tag}'
      ORDER BY TIMESTAMP DESC
      LIMIT ${limit}
    `, warehouse);
    return NextResponse.json(results.reverse());
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Failed to fetch data" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { query } from "@/lib/snowflake";

interface StatsRow {
  TAGNAME: string;
  MIN_VALUE: number;
  MAX_VALUE: number;
  AVG_VALUE: number;
  STDDEV_VALUE: number;
  COUNT: number;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const warehouse = searchParams.get("warehouse") || undefined;
  const tag = searchParams.get("tag");

  try {
    const sql = tag
      ? `SELECT 
          TAGNAME,
          MIN(VALUE) as MIN_VALUE,
          MAX(VALUE) as MAX_VALUE,
          AVG(VALUE) as AVG_VALUE,
          STDDEV(VALUE) as STDDEV_VALUE,
          COUNT(*) as COUNT
        FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2
        WHERE TAGNAME = '${tag}'
        GROUP BY TAGNAME`
      : `SELECT 
          TAGNAME,
          MIN(VALUE) as MIN_VALUE,
          MAX(VALUE) as MAX_VALUE,
          AVG(VALUE) as AVG_VALUE,
          STDDEV(VALUE) as STDDEV_VALUE,
          COUNT(*) as COUNT
        FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2
        GROUP BY TAGNAME
        ORDER BY TAGNAME`;
    
    const results = await query<StatsRow>(sql, warehouse);
    return NextResponse.json(results);
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 });
  }
}

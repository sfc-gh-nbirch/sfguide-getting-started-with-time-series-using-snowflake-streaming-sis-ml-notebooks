import { NextResponse } from "next/server";
import { query } from "@/lib/snowflake";

interface TagRow {
  TAGNAME: string;
  COUNT: number;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const warehouse = searchParams.get("warehouse") || undefined;

  try {
    const results = await query<TagRow>(`
      SELECT TAGNAME, COUNT(*) as COUNT
      FROM HOL_TIMESERIES.STAGING.RAW_TS_IOTSTREAM_DATA2
      GROUP BY TAGNAME
      ORDER BY TAGNAME
    `, warehouse);
    return NextResponse.json(results);
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Failed to fetch tags" }, { status: 500 });
  }
}

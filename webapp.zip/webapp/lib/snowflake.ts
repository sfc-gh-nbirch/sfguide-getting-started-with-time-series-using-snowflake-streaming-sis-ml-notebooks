import snowflake from "snowflake-sdk";
import fs from "fs";
import path from "path";
import crypto from "crypto";

snowflake.configure({ logLevel: "ERROR" });

let connection: snowflake.Connection | null = null;
let currentWarehouse: string | null = null;

function loadPrivateKey(): string | null {
  const keyPaths = [
    path.join(process.cwd(), "..", "keys", "rsa_key.p8"),
    path.join(process.cwd(), "keys", "rsa_key.p8"),
    process.env.SNOWFLAKE_PRIVATE_KEY_FILE || "",
  ];

  for (const keyPath of keyPaths) {
    if (keyPath && fs.existsSync(keyPath)) {
      console.log(`Loading private key from: ${keyPath}`);
      const keyContent = fs.readFileSync(keyPath, "utf8");
      const privateKey = crypto.createPrivateKey({
        key: keyContent,
        format: "pem",
      });
      return privateKey.export({ type: "pkcs8", format: "pem" }) as string;
    }
  }
  return null;
}

function getConfig(): snowflake.ConnectionOptions {
  const privateKey = loadPrivateKey();

  if (privateKey) {
    return {
      account: process.env.SNOWFLAKE_ACCOUNT || "SFPSCOGS-AU_DEMO89",
      username: process.env.SNOWFLAKE_USER || "USER_HOL_TIMESERIES",
      privateKey: privateKey,
      authenticator: "SNOWFLAKE_JWT",
      warehouse: process.env.SNOWFLAKE_WAREHOUSE || "COMPUTE_WH",
      database: process.env.SNOWFLAKE_DATABASE || "HOL_TIMESERIES",
      schema: process.env.SNOWFLAKE_SCHEMA || "STAGING",
    };
  }

  return {
    account: process.env.SNOWFLAKE_ACCOUNT || "SFPSCOGS-AU_DEMO89",
    username: process.env.SNOWFLAKE_USER || "",
    authenticator: "EXTERNALBROWSER",
    warehouse: process.env.SNOWFLAKE_WAREHOUSE || "COMPUTE_WH",
    database: process.env.SNOWFLAKE_DATABASE || "HOL_TIMESERIES",
    schema: process.env.SNOWFLAKE_SCHEMA || "STAGING",
  };
}

async function getConnection(): Promise<snowflake.Connection> {
  if (connection) {
    return connection;
  }

  const config = getConfig();
  console.log(`Connecting to Snowflake as ${config.username} using ${config.authenticator}`);
  
  const conn = snowflake.createConnection(config);
  await conn.connectAsync(() => {});
  connection = conn;
  return connection;
}

function isRetryableError(err: unknown): boolean {
  const error = err as { message?: string; code?: number };
  return !!(
    error.message?.includes("OAuth access token expired") ||
    error.message?.includes("terminated connection") ||
    error.code === 407002
  );
}

export async function query<T>(sql: string, warehouse?: string, retries = 1): Promise<T[]> {
  try {
    const conn = await getConnection();
    
    if (warehouse && warehouse !== currentWarehouse) {
      await new Promise<void>((resolve, reject) => {
        conn.execute({
          sqlText: `USE WAREHOUSE ${warehouse}`,
          complete: (err) => err ? reject(err) : resolve(),
        });
      });
      currentWarehouse = warehouse;
      console.log(`Switched to warehouse: ${warehouse}`);
    }
    
    return await new Promise<T[]>((resolve, reject) => {
      conn.execute({
        sqlText: sql,
        complete: (err, stmt, rows) => {
          if (err) {
            reject(err);
          } else {
            resolve((rows || []) as T[]);
          }
        },
      });
    });
  } catch (err) {
    console.error("Query error:", (err as Error).message);
    if (retries > 0 && isRetryableError(err)) {
      connection = null;
      currentWarehouse = null;
      return query(sql, warehouse, retries - 1);
    }
    throw err;
  }
}
